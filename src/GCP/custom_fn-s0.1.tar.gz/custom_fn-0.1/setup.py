from setuptools import setup

setup(
     name="custom_fn",
     version="0.1",
     include_package_data=True,
     scripts=["text_proc.py","customPred.py"]
)